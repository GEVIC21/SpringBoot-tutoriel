package com.cours.se352.services;

import com.cours.se352.models.Auteur;

public interface MonService{
    String salutationGenre(Auteur auteur);
}
