package com.cours.se352;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Se352ApplicationTests {

	@Test
	void contextLoads() {
	}

}
