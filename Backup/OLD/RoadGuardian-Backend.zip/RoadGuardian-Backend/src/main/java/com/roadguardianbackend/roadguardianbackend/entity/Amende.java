package com.roadguardianbackend.roadguardianbackend.entity;

import java.util.UUID;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@AllArgsConstructor
@Table(name="Amende")

public class Amende {
    @Id
    private String id;
    public Amende(){
        this.id=UUID.randomUUID().toString();
    }
    private String title;
    private String description;
    private String makeAt;
    private long price;
    private boolean isPaid;
    //private Vehicule vehicule;
    
}
