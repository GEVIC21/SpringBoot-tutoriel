package com.roadguardianbackend.roadguardianbackend.utility;

import com.auth0.jwt.JWT;
import com.auth0.jwt.JWTVerifier;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.exceptions.JWTVerificationException;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.roadguardianbackend.roadguardianbackend.domain.UserPrincipal;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.Date;
import java.util.stream.Collectors;

import static com.roadguardianbackend.roadguardianbackend.constant.SecurityConstant.*;

@Component
public class JwtTokenProvider {

    private final String secret;
    private final long jwtExpirationInMs;


    public JwtTokenProvider(@Value("${jwt.secret}") String secret,
                            @Value("${jwt.expirationInMs}") Long jwtExpirationInMs) {
        this.secret = secret;
        this.jwtExpirationInMs = jwtExpirationInMs;
    }

//    public String generateToken(Authentication authentication) {
//        UserPrincipal userPrincipal = (UserPrincipal) authentication.getPrincipal();
//
//        Date now = new Date();
//        Date expiryDate = new Date(now.getTime() + jwtExpirationInMs);
//
//        return JWT.create()
//                .withSubject(userPrincipal.getUsername())
//                .withIssuedAt(new Date())
//                .withExpiresAt(expiryDate)
//                .withClaim(AUTHORITIES, userPrincipal.getAuthorities().stream()
//                        .map(GrantedAuthority::getAuthority)
//                        .collect(Collectors.toList()))
//                .sign(Algorithm.HMAC512(secret));
//    }
public String generateToken(Authentication authentication) {
    String username = ((UserPrincipal) authentication.getPrincipal()).getUsername();
    return JWT.create()
            .withSubject(username)
            .withIssuedAt(new Date())
            .withExpiresAt(new Date(System.currentTimeMillis() + jwtExpirationInMs))
            .withClaim(AUTHORITIES, authentication.getAuthorities().stream()
                    .map(GrantedAuthority::getAuthority)
                    .collect(Collectors.toList()))
            .sign(Algorithm.HMAC512(secret.getBytes()));
}

    public String extractUsername(String token) {
        return decodeJWT(token).getSubject();
    }

    public boolean isTokenValid(String token, UserPrincipal userPrincipal) {
        final String username = extractUsername(token);
        return (username.equals(userPrincipal.getUsername())) && !isTokenExpired(token);
    }

    private boolean isTokenExpired(String token) {
        Date expirationDate = decodeJWT(token).getExpiresAt();
        return expirationDate.before(new Date());
    }

    private DecodedJWT decodeJWT(String token) {
        try {
            Algorithm algorithm = Algorithm.HMAC512(secret);
            JWTVerifier verifier = JWT.require(algorithm)
                    .withIssuer(GET_ARRAYS_LLC)
                    .build();
            return verifier.verify(token);
        } catch (JWTVerificationException e) {
            throw new JWTVerificationException(TOKEN_CANNOT_BE_VERIFIED);
        }
    }
}