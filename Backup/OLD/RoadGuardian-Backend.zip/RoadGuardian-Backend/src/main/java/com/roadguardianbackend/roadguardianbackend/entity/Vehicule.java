package com.roadguardianbackend.roadguardianbackend.entity;

import jakarta.persistence.*;
import lombok.*;

//
//
@Entity
@Table(name = "vehicule")
@Data
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Vehicule {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
   private Long id;

   @Column(name = "driver_full_name")
    private String driverFullName;

    @Column(name = "car_registration")
   private String carRegistration;

    @Column(name="details")
   private String details;

   @Column(name = "driving_licence_number")
    private Long drivingLicenceNumber;
}
 
