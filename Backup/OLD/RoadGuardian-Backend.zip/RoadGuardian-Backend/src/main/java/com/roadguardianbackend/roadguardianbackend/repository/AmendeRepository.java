package com.roadguardianbackend.roadguardianbackend.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.roadguardianbackend.roadguardianbackend.entity.Amende;

public interface AmendeRepository extends JpaRepository<Amende,String> {
    
}
