package com.roadguardianbackend.roadguardianbackend.entity;

import java.util.Date;
import java.util.UUID;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Setter;
import lombok.Getter;

@Entity
@Getter
@Setter
@Table(name="Rapport")
@AllArgsConstructor

public class Rapport {
    @Id
    private String id;
    public Rapport(){
        this.id=UUID.randomUUID().toString();
    }
    private Date date;
    private String titre;
    private String type;
    private String description;
    private String details;
    private ControleRoutier controleRoutier;
    
}
