package com.roadguardianbackend.roadguardianbackend.service;

import com.roadguardianbackend.roadguardianbackend.entity.Role;
import com.roadguardianbackend.roadguardianbackend.entity.User;
import com.roadguardianbackend.roadguardianbackend.exception.domain.EmailExistException;
import com.roadguardianbackend.roadguardianbackend.exception.domain.UserNotFoundException;
import com.roadguardianbackend.roadguardianbackend.exception.domain.UsernameExistException;

import java.util.List;

public interface UserService {
    User register(String firstName, String lastName,  String username, String email) throws UserNotFoundException, EmailExistException, UsernameExistException;
        List<User> getUsers();
        User findUserByUsername(String username);
        User findUserByEmail(String email);


}
