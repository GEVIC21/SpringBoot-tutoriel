package com.roadguardianbackend.roadguardianbackend.dto;

import lombok.Data;

@Data
public class VehiculeDto {

    private Long id;
    private String modele;
    private String plaque_immatriculation;
}
