package com.roadguardianbackend.roadguardianbackend.controller;

import com.roadguardianbackend.roadguardianbackend.domain.UserPrincipal;
import com.roadguardianbackend.roadguardianbackend.entity.Role;
import com.roadguardianbackend.roadguardianbackend.exception.domain.EmailExistException;
import com.roadguardianbackend.roadguardianbackend.exception.domain.ExceptionHandling;
import com.roadguardianbackend.roadguardianbackend.exception.domain.UserNotFoundException;
import com.roadguardianbackend.roadguardianbackend.exception.domain.UsernameExistException;
import com.roadguardianbackend.roadguardianbackend.service.UserService;
import com.roadguardianbackend.roadguardianbackend.entity.User;
import com.roadguardianbackend.roadguardianbackend.utility.JwtTokenProvider;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.net.URI;
import java.util.List;

import static com.roadguardianbackend.roadguardianbackend.constant.SecurityConstant.JWT_TOKEN_HEADER;
import static org.springframework.http.HttpStatus.OK;

@RequestMapping(path = {"/","/user"})
@RestController
@RequiredArgsConstructor
public class UserController extends ExceptionHandling {
    @Autowired
    private UserService userService;
    @Autowired
    private AuthenticationManager authenticationManager;
    @Autowired
    private JwtTokenProvider jwtTokenProvider;




//    @PostMapping("/login")
//    public ResponseEntity<User> login(@RequestBody User user) {
//        authenticate(user.getUsername(), user.getPassword());
//        User loginUser = userService.findUserByUsername(user.getUsername());
//        UserPrincipal userPrincipal = new UserPrincipal(loginUser);
//        HttpHeaders jwtHeader = getJwtHeader(userPrincipal);
//        return new ResponseEntity<>(loginUser,jwtHeader, OK);
//
//    }

    // Endpoint pour se connecter
    @PostMapping("/login")
    public ResponseEntity<User> login(@RequestBody User user) {
        Authentication authentication = authenticate(user.getUsername(), user.getPassword());
        User loginUser = userService.findUserByUsername(user.getUsername());
        UserPrincipal userPrincipal = new UserPrincipal(loginUser);
        HttpHeaders jwtHeader = getJwtHeader(authentication);
        return new ResponseEntity<>(loginUser, jwtHeader, OK);}

    // Méthode d'aide pour authentifier l'utilisateur
    private Authentication authenticate(String username, String password) {
        return authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(username, password));
    }

    // Méthode d'aide pour obtenir l'entête JWT.
    private HttpHeaders getJwtHeader(Authentication authentication) {
        HttpHeaders headers = new HttpHeaders();
        String jwtToken = jwtTokenProvider.generateToken(authentication);
        headers.add(JWT_TOKEN_HEADER,  jwtToken);
        return headers;
    }

    @PostMapping("/register")
    public ResponseEntity<User> register(@RequestBody User user) throws UserNotFoundException, EmailExistException, UsernameExistException {
      User newUser =  userService.register(user.getFirstName(), user.getLastName(),  user.getUsername(), user.getEmail());
      return new ResponseEntity<>(newUser, OK);

    }

    private HttpHeaders getJwtHeader(UserPrincipal user) {
        HttpHeaders headers = new HttpHeaders();
        headers.add(JWT_TOKEN_HEADER, jwtTokenProvider.generateToken((Authentication) user));
        return headers;
    }

//    private void authenticate(String username, String password) {
//        authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(username,password));
//    }



}

