package com.roadguardianbackend.roadguardianbackend.service;

import com.roadguardianbackend.roadguardianbackend.entity.Role;

public interface RoleService {
    Role addRole(Role role);
    Role updateRole(String id,Role role);
    void deleteRole(String id);

}
