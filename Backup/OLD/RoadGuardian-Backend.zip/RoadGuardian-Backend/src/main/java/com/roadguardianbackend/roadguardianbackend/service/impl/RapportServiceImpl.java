package com.roadguardianbackend.roadguardianbackend.service.impl;

import java.util.List;
import java.util.Optional;

import com.roadguardianbackend.roadguardianbackend.entity.Rapport;
import com.roadguardianbackend.roadguardianbackend.repository.RapportRepository;
import com.roadguardianbackend.roadguardianbackend.service.RapportService;

public class RapportServiceImpl  implements RapportService{

    private RapportRepository rapportRepository;

    @Override
    public List<Rapport> listRapport() {
        return rapportRepository.findAll();
    }

    @Override
    public Optional<Rapport> findRapportById(String id) {
        return rapportRepository.findById(id);
    }

    @Override
    public Rapport addRapport(Rapport rapport) {
        return rapportRepository.save(rapport);
    }

    @Override
    public Rapport updateRapport(String id, Rapport rapport) {
        if(rapportRepository.existsById(id)){
            rapport.setId(id);
            return rapportRepository.save(rapport);
        }
        return null;
        
    }

    @Override
    public void deleteRapport(String id) {
        rapportRepository.deleteById(id);
    }
    
}
