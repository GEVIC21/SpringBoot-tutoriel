package com.roadguardianbackend.roadguardianbackend.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.roadguardianbackend.roadguardianbackend.entity.Rapport;

public interface RapportRepository extends JpaRepository<Rapport,String>{
    
}
