 package com.roadguardianbackend.roadguardianbackend.entity;

 import jakarta.persistence.*;
 import lombok.Data;
 import org.hibernate.annotations.CreationTimestamp;

 import java.util.Date;
 import java.util.UUID;

 @Entity
 @Data
 @Table(name = "controle_routier")
 public class ControleRoutier {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @CreationTimestamp
    private Date date_created;
    private String lieu;
    private User user;
    private Vehicule vehicule;
 }
