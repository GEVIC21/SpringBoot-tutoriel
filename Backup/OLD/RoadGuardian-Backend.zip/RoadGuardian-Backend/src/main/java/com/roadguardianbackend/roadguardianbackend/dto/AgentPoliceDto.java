package com.roadguardianbackend.roadguardianbackend.dto;

import lombok.Data;

@Data
public class AgentPoliceDto {

    private Long id;
    private String nom;
}
