package com.roadguardianbackend.roadguardianbackend.service;

import java.util.List;
import java.util.Optional;

import com.roadguardianbackend.roadguardianbackend.entity.Rapport;

public interface RapportService {
    
    List<Rapport> listRapport();
    Optional<Rapport>  findRapportById(String id);
    Rapport addRapport(Rapport rapport);
    Rapport updateRapport(String id,Rapport rapport);
    void deleteRapport(String id);
    
}
