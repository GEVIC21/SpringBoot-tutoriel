package com.roadguardianbackend.roadguardianbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RoadGuardianBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
