package dao;

public interface IDao {
    public double getData();
}
